import numpy as np
import pickle
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque

# 设备检测：优先使用 Apple 的 mps (Metal)，然后是 cuda，最后是 cpu
device = torch.device("mps" if torch.backends.mps.is_available() else "cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

class QLearningAgent:
    def __init__(self, actions, learning_rate=0.1, reward_decay=0.9, e_greedy=0.9):
        self.actions = actions 
        self.lr = learning_rate
        self.gamma = reward_decay
        self.epsilon = e_greedy
        self.q_table = {} # 使用字典存储，key为坐标(x,y)，value为长度为4的数组

    def check_state_exist(self, state):
        if state not in self.q_table:
            # 初始化该状态的 Q 值为 0
            self.q_table[state] = np.zeros(len(self.actions))

    def choose_action(self, state, is_training=True):
        self.check_state_exist(state)
        # Epsilon-Greedy 策略
        if is_training and np.random.uniform() > self.epsilon:
            # 随机探索
            action = np.random.choice(len(self.actions))
        else:
            # 选择 Q 值最大的动作
            state_action = self.q_table[state]
            # 处理有多个最大值的情况，随机选择其中一个
            action = np.random.choice(np.where(state_action == np.max(state_action))[0])
        return action

    def learn(self, s, a, r, s_next, done):
        self.check_state_exist(s_next)
        q_predict = self.q_table[s][a]
        
        if not done:
            # Bellman 方程: Q_new = Q_old + lr * (Reward + gamma * max(Q_next) - Q_old)
            q_target = r + self.gamma * self.q_table[s_next].max()
        else:
            q_target = r  # 终点没有下一步

        self.q_table[s][a] += self.lr * (q_target - q_predict)

    def get_path(self, env, start, end):
        """利用训练好的 Q 表输出路径"""
        path = [start]
        curr = start
        env.agent_pos = list(start)
        steps = 0
        max_steps = env.rows * env.cols * 2 # 防止死循环
        
        while curr != end and steps < max_steps:
            action = self.choose_action(curr, is_training=False)
            next_state, _, done = env.step(action)
            
            if next_state == curr: # 撞墙或者卡住
                 break
                 
            path.append(next_state)
            curr = next_state
            steps += 1
            if done:
                break
        
        if curr != end:
            return None # 无法到达
        return path

# --- 新增 DQN Agent (支持 MPS 加速) ---
class QNet(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(QNet, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        )
    
    def forward(self, x):
        return self.fc(x)

class DQNAgent:
    def __init__(self, state_dim, action_dim, lr=0.001, gamma=0.9, epsilon=0.9, memory_size=2000, batch_size=32):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.epsilon = epsilon
        self.batch_size = batch_size
        self.memory = deque(maxlen=memory_size)
        
        # 主网络和目标网络
        self.model = QNet(state_dim, action_dim).to(device)
        self.target_model = QNet(state_dim, action_dim).to(device)
        self.target_model.load_state_dict(self.model.state_dict())
        
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.loss_fn = nn.MSELoss()
        self.learn_step_counter = 0

    def choose_action(self, state, is_training=True):
        # 将状态转换为 tensor 并移动到 MPS 设备
        state_tensor = torch.FloatTensor(state).to(device)
        if is_training and random.random() > self.epsilon:
            return random.randint(0, self.action_dim - 1)
        
        with torch.no_grad():
            actions_value = self.model(state_tensor)
        return torch.argmax(actions_value).item()

    def store_transition(self, s, a, r, s_next, done):
        self.memory.append((s, a, r, s_next, done))

    def learn(self):
        if len(self.memory) < self.batch_size:
            return

        # 目标网络定期更新
        if self.learn_step_counter % 100 == 0:
            self.target_model.load_state_dict(self.model.state_dict())
        self.learn_step_counter += 1

        # 随机采样并移动到 MPS 设备
        batch = random.sample(self.memory, self.batch_size)
        s_batch = torch.FloatTensor([x[0] for x in batch]).to(device)
        a_batch = torch.LongTensor([x[1] for x in batch]).view(-1, 1).to(device)
        r_batch = torch.FloatTensor([x[2] for x in batch]).view(-1, 1).to(device)
        s_next_batch = torch.FloatTensor([x[3] for x in batch]).to(device)
        done_batch = torch.FloatTensor([float(x[4]) for x in batch]).view(-1, 1).to(device)

        # 计算 Q 估计值和 Q 目标值
        q_eval = self.model(s_batch).gather(1, a_batch)
        q_next = self.target_model(s_next_batch).detach().max(1)[0].view(-1, 1)
        q_target = r_batch + self.gamma * q_next * (1 - done_batch)

        loss = self.loss_fn(q_eval, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def get_path(self, env, start, end):
        path = [start]
        curr = start
        env.agent_pos = list(start)
        steps = 0
        max_steps = env.rows * env.cols * 2
        while curr != end and steps < max_steps:
            action = self.choose_action(curr, is_training=False)
            next_state, _, done = env.step(action)
            if next_state == curr: break
            path.append(next_state)
            curr = next_state
            steps += 1
            if done: break
        return path if curr == end else None
