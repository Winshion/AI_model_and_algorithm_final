import cv2
import numpy as np
import pygame

class MazeEnv:
    def __init__(self, image_path, cell_size=20):
        self.cell_size = cell_size
        self.grid = self.load_maze_from_image(image_path)
        self.rows, self.cols = self.grid.shape
        self.start_pos = None
        self.end_pos = None
        self.agent_pos = None
        
        # 动作空间: 上, 下, 左, 右
        self.actions = ['up', 'down', 'left', 'right']
        self.n_actions = len(self.actions)

    def load_maze_from_image(self, image_path):
        """
        读取图片并转换为 0/1 矩阵。
        0 = 通路, 1 = 墙壁
        注意：这里假设迷宫是黑白分明的。需要根据实际图片调整阈值或缩放。
        """
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise ValueError("无法读取图片，请检查路径。")

        # 二值化处理：黑色(低像素值)为墙，白色为路
        # 你的图片墙壁有纹理，可能需要调整 threshold 或者先模糊一下
        _, thresh = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
        
        # 图像通常很大，我们需要将其缩放到合理的网格大小
        # 这里是一个简单的处理：根据 cell_size 重新采样
        # 更好的方法是根据迷宫实际的像素块大小进行步长采样
        h, w = thresh.shape
        grid_h = h // self.cell_size
        grid_w = w // self.cell_size
        
        # 缩放图像到网格大小 (使用最近邻插值保持黑白边界)
        small_img = cv2.resize(thresh, (grid_w, grid_h), interpolation=cv2.INTER_NEAREST)
        
        # 反转颜色：在该逻辑中，通常习惯 1 是墙，0 是路
        # 原始图：黑墙(0) 白路(255)。
        # 我们希望：墙=1, 路=0
        grid = (small_img < 127).astype(int) 
        
        return grid

    def reset(self, start_pos, end_pos):
        self.start_pos = start_pos
        self.end_pos = end_pos
        self.agent_pos = list(start_pos)
        return tuple(self.agent_pos)

    def step(self, action_idx):
        """
        执行动作，返回：next_state, reward, done
        """
        x, y = self.agent_pos
        base_reward = -1  # 每走一步扣1分，鼓励最短路径
        
        if action_idx == 0:   # Up
            nx, ny = x, y - 1
        elif action_idx == 1: # Down
            nx, ny = x, y + 1
        elif action_idx == 2: # Left
            nx, ny = x - 1, y
        elif action_idx == 3: # Right
            nx, ny = x + 1, y
        
        # 检查碰撞
        if 0 <= ny < self.rows and 0 <= nx < self.cols:
            if self.grid[ny, nx] == 0: # 0 是路
                self.agent_pos = [nx, ny]
            else:
                # 撞墙，留在原地，并给予惩罚
                return tuple(self.agent_pos), -10, False
        else:
            # 出界，留在原地
            return tuple(self.agent_pos), -10, False
            
        # 检查是否到达终点
        if tuple(self.agent_pos) == self.end_pos:
            return tuple(self.agent_pos), 100, True # 到达终点，奖励100
            
        return tuple(self.agent_pos), base_reward, False

    def is_valid(self, pos):
        x, y = pos
        if 0 <= x < self.cols and 0 <= y < self.rows:
            return self.grid[y, x] == 0
        return False