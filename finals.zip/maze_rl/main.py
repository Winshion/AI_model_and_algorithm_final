import pygame
import sys
from maze_env import MazeEnv
from rl_agent import QLearningAgent, DQNAgent
from tqdm import tqdm

# --- 配置参数 ---
IMAGE_PATH = 'maze.jpg' # 你的图片文件名
CELL_SIZE = 8          # 每个网格的像素大小
TRAIN_EPISODES = 500    # 训练轮数
FPS = 60
AGENT_TYPE = 'QL'      # 可选: 'QL' (Q-Learning), 'DQN' (Deep Q-Network)

# 颜色定义
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)     # 终点
GREEN = (0, 255, 0)   # 起点
BLUE = (0, 0, 255)    # 路径
YELLOW = (255, 255, 0)# Agent

def main():
    pygame.init()
    
    # 1. 初始化环境
    try:
        env = MazeEnv(IMAGE_PATH, cell_size=CELL_SIZE)
    except Exception as e:
        print(f"错误: {e}")
        return

    # 计算窗口大小
    window_width = env.cols * CELL_SIZE
    window_height = env.rows * CELL_SIZE
    screen = pygame.display.set_mode((window_width, window_height))
    pygame.display.set_caption("RL Maze Solver - 1: Start, 2: End, Space: Train")
    clock = pygame.time.Clock()

    # 2. 初始化 Agent
    if AGENT_TYPE == 'DQN':
        agent = DQNAgent(state_dim=2, action_dim=env.n_actions)
    else:
        agent = QLearningAgent(actions=list(range(env.n_actions)))

    # 状态变量
    start_pos = None
    end_pos = None
    path = []
    is_training = False
    
    running = True
    while running:
        screen.fill(WHITE)
        
        # --- 事件处理 ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # 按键盘 1 设置起点，2 设置终点 (在当前鼠标位置)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1 or event.key == pygame.K_2:
                    mx, my = pygame.mouse.get_pos()
                    gx, gy = mx // CELL_SIZE, my // CELL_SIZE
                    
                    if env.is_valid((gx, gy)):
                        if event.key == pygame.K_1: # 按 1 设置起点
                            start_pos = (gx, gy)
                            path = [] # 重置路径
                            print(f"起点设置为: {start_pos}")
                        elif event.key == pygame.K_2: # 按 2 设置终点
                            end_pos = (gx, gy)
                            path = [] # 重置路径
                            print(f"终点设置为: {end_pos}")
                    else:
                        print("该位置是墙壁或无效位置，无法设置起点/终点。")

                # 按空格键开始训练
                elif event.key == pygame.K_SPACE:
                    if start_pos and end_pos:
                        is_training = True
                        path = []
                    else:
                        print("请先设置起点和终点！")

        # --- 训练逻辑 (如果触发) ---
        if is_training:
            print(f"开始训练 {TRAIN_EPISODES} 轮...")
            for episode in tqdm(range(TRAIN_EPISODES)):
                state = env.reset(start_pos, end_pos)
                while True:
                    action = agent.choose_action(state)
                    next_state, reward, done = env.step(action)
                    
                    if AGENT_TYPE == 'DQN':
                        agent.store_transition(state, action, reward, next_state, done)
                        agent.learn()
                    else:
                        agent.learn(state, action, reward, next_state, done)
                        
                    state = next_state
                    if done:
                        break
            
            print("训练完成！生成路径...")
            is_training = False
            # 获取最优路径
            final_path = agent.get_path(env, start_pos, end_pos)
            if final_path:
                path = final_path
                print(f"找到路径，步数: {len(path)}")
            else:
                print("未找到路径或不可达。")

        # --- 绘图 ---
        # 1. 绘制迷宫墙壁
        for r in range(env.rows):
            for c in range(env.cols):
                if env.grid[r, c] == 1: # 墙壁
                    pygame.draw.rect(screen, BLACK, (c*CELL_SIZE, r*CELL_SIZE, CELL_SIZE, CELL_SIZE))
        
        # 2. 绘制起点和终点
        if start_pos:
            pygame.draw.rect(screen, GREEN, (start_pos[0]*CELL_SIZE, start_pos[1]*CELL_SIZE, CELL_SIZE, CELL_SIZE))
        if end_pos:
            pygame.draw.rect(screen, RED, (end_pos[0]*CELL_SIZE, end_pos[1]*CELL_SIZE, CELL_SIZE, CELL_SIZE))

        # 3. 绘制解出的路径
        if path:
            for (px, py) in path:
                # 绘制小一点的方块表示路径
                center_x = px * CELL_SIZE + CELL_SIZE // 2
                center_y = py * CELL_SIZE + CELL_SIZE // 2
                pygame.draw.circle(screen, BLUE, (center_x, center_y), CELL_SIZE // 3)

        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
