import pandas as pd
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor, StackingRegressor
from sklearn.linear_model import RidgeCV
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import csv
import warnings

# 忽略一些警告信息
warnings.filterwarnings('ignore')

def load_data():
    """
    加载训练集和测试集数据
    train.xlsx: 训练集
    test.xlsx: Sheet2 为测试集
    前30列：治疗前指标（数值型）
    第31列：所服药物（分类型）
    第32列：治疗后总分（目标数值）
    """
    # 读取训练集
    train_df = pd.read_excel('train.xlsx')
    # 读取测试集 (Sheet2 通常索引为 1)
    test_df = pd.read_excel('test.xlsx', sheet_name=1)
    
    # 特征和标签切片
    # 前31列 (0-30) 为特征
    X_train = train_df.iloc[:, :31]
    # 第32列 (31) 为目标值
    y_train = train_df.iloc[:, 31]
    
    X_test = test_df.iloc[:, :31]
    y_test = test_df.iloc[:, 31]
    
    return X_train, X_test, y_train, y_test

def get_model():
    """
    设计集成学习模型：使用 Stacking 策略集成随机森林、XGBoost 和 LightGBM
    """
    # 处理第31列（索引为30）的类别型药物数据
    categorical_features = [30]
    numerical_features = list(range(30))

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', 'passthrough', numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
        ])

    # 定义基础回归模型
    estimators = [
        ('rf', RandomForestRegressor(random_state=42)),
        ('xgb', XGBRegressor(random_state=42, n_jobs=-1)),
        ('lgbm', LGBMRegressor(random_state=42, verbose=-1, n_jobs=-1))
    ]
    
    # 使用 RidgeCV 作为最终融合层（元模型）
    stacking_regressor = StackingRegressor(
        estimators=estimators,
        final_estimator=RidgeCV()
    )
    
    # 封装为 Pipeline
    model_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', stacking_regressor)
    ])
    
    return model_pipeline

def train_with_cv(X_train, y_train):
    """
    使用交叉验证进行超参数优化
    """
    model = get_model()
    
    # 定义待优化的超参数网格
    # 注意 Pipeline 中参数的命名规则：步骤名__模型名__参数名
    param_grid = {
        'regressor__rf__n_estimators': [100, 200],
        'regressor__rf__max_depth': [None, 10],
        'regressor__xgb__learning_rate': [0.01, 0.1],
        'regressor__lgbm__learning_rate': [0.01, 0.1]
    }
    
    # 使用 5 折交叉验证寻找最优参数
    grid_search = GridSearchCV(
        model, 
        param_grid, 
        cv=5, 
        scoring='neg_mean_squared_error',
        n_jobs=-1
    )
    
    print("正在进行交叉验证寻优...")
    grid_search.fit(X_train, y_train)
    print(f"最优参数组合: {grid_search.best_params_}")
    
    return grid_search.best_estimator_

def evaluate_and_report(model, X_test, y_test):
    """
    在测试集上评估，计算平方和相对误差，并保存均值和方差
    """
    # 预测结果
    y_pred = model.predict(X_test)
    
    # 计算每个样本的“平方和相对误差” (Squared Relative Error)
    # 定义为: ((预测值 - 真实值) / 真实值)^2
    # 为了避免除零错误，加入一个极小值 epsilon
    epsilon = 1e-10
    relative_squared_errors = ((y_pred - y_test) / (y_test + epsilon))**2
    
    # 计算测试集误差的均值和方差
    mean_err = np.mean(relative_squared_errors)
    var_err = np.var(relative_squared_errors)
    
    # 将结果保存到 CSV 文件
    output_path = 'error_report.csv'
    with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['指标', '数值'])
        writer.writerow(['测试样本误差均值 (Mean Squared Relative Error)', mean_err])
        writer.writerow(['测试样本误差方差 (Variance of Squared Relative Error)', var_err])
    
    print(f"\n评估完成！")
    print(f"测试集误差均值: {mean_err:.6f}")
    print(f"测试集误差方差: {var_err:.6f}")
    print(f"结果已保存至: {output_path}")

if __name__ == "__main__":
    try:
        # 1. 加载数据
        X_train, X_test, y_train, y_test = load_data()
        
        # 2. 训练模型并寻优
        best_model = train_with_cv(X_train, y_train)
        
        # 3. 预测、计算误差并报告
        evaluate_and_report(best_model, X_test, y_test)
        
    except Exception as e:
        print(f"脚本执行过程中出现错误: {e}")

